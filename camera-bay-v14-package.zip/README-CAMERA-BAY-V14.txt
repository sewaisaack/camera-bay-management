CAMERA BAY MANAGEMENT — V14 UPDATE PACKAGE

Current status:
- Supabase RPC functions installed: stock_transfer, stock_out, record_pos_sale, camera_bay_reports.
- The JS file in this package adds forms for transfer, stock out, POS and reporting.
- This file is NOT YET published to GitHub Pages because the connected GitHub integration returns 403 on write.

Installation (when GitHub write access is available):
1. Add camera-bay-v14.js to the root of sewaisaack/camera-bay-management.
2. In index.html, immediately AFTER <script src="camera-bay-v9.js"></script> and BEFORE </body>, add:
   <script src="camera-bay-v14.js"></script>
3. Update V8 labels/notice to reflect new modules and refresh the site.
4. Verify permissions and end-to-end sales/stock using a dedicated test item before production use.

IMPORTANT: The POS module will change live stock and sales when used. It has not been end-to-end tested with an authenticated session. Do not use it for actual sales until tested.
Gross profit is estimated from recorded buying prices and excludes operating expenses.
